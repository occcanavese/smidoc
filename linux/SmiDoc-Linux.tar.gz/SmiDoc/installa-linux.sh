#!/bin/sh
# =====================================================================
#  SmiDoc - installazione su Linux (Ubuntu, Linux Mint, Debian e derivate)
#  Uso:  sh installa-linux.sh     (dalla cartella in cui hai scompattato SmiDoc)
# =====================================================================
set -e
APP="$(cd "$(dirname "$0")" && pwd)"
cd "$APP"
echo "== Installazione di SmiDoc in $APP =="

# 1) programmi di sistema: Python, Tk (finestre), Tesseract con l'italiano
MANCANO=""
command -v python3 >/dev/null 2>&1 || MANCANO="$MANCANO python3"
python3 -c "import venv" 2>/dev/null || MANCANO="$MANCANO python3-venv"
python3 -c "import tkinter" 2>/dev/null || MANCANO="$MANCANO python3-tk"
command -v tesseract >/dev/null 2>&1 || MANCANO="$MANCANO tesseract-ocr"
if command -v tesseract >/dev/null 2>&1; then
    tesseract --list-langs 2>/dev/null | grep -qx ita || MANCANO="$MANCANO tesseract-ocr-ita"
else
    MANCANO="$MANCANO tesseract-ocr-ita"
fi
if [ -n "$MANCANO" ]; then
    echo "1/3 Servono questi pacchetti di sistema:$MANCANO"
    echo "    (ti verrà chiesta la password per installarli)"
    sudo apt-get update -qq
    # shellcheck disable=SC2086
    sudo apt-get install -y $MANCANO
else
    echo "1/3 Programmi di sistema già presenti"
fi

# 2) ambiente Python e librerie
echo "2/3 Preparo l'ambiente e installo le librerie (qualche minuto)..."
[ -x .venv/bin/python ] || python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip install -r requirements.txt --quiet
chmod +x smidoc

# 3) voce nel menu delle applicazioni
echo "3/3 Aggiungo SmiDoc al menu delle applicazioni..."
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/smidoc.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=SmiDoc
Comment=Smistatore di documenti per le pratiche di sovraindebitamento
Exec=$APP/smidoc
Icon=document-import
Terminal=false
Categories=Office;
EOF

echo ""
echo "Fatto! Avvia SmiDoc dal menu (cerca «SmiDoc») oppure con:  $APP/smidoc"
