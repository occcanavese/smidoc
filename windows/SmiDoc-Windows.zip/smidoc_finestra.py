#!/usr/bin/env python3
"""SmiDoc - finestra semplice: trascina i file, scegli la pratica, premi Avvia."""
import datetime as dt
import json
import queue
import shutil
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    DND = True
except ImportError:
    DND = False

import smidoc

import os
import sys

WINDOWS = sys.platform.startswith("win")
if WINDOWS:   # %APPDATA%\SmiDoc e %LOCALAPPDATA%\SmiDoc
    PREFERENZE = Path(os.environ.get("APPDATA", Path.home())) / "SmiDoc" / "preferenze.json"
    APPOGGIO = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "SmiDoc" / "appoggio"
else:
    PREFERENZE = Path.home() / ".config" / "smidoc.json"
    APPOGGIO = Path.home() / ".cache" / "smidoc"
# APPOGGIO: copie dei file trascinati (gli originali non si toccano)
GUIDA = smidoc.QUI / "guida.md"
FONT_LOG = ("Consolas", 9) if WINDOWS else ("Monospace", 9)


def carica_pref():
    try:
        return json.loads(PREFERENZE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def salva_pref(d):
    PREFERENZE.parent.mkdir(parents=True, exist_ok=True)
    PREFERENZE.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


class Finestra:
    def __init__(self, root):
        self.root = root
        self.file = []
        self.coda = queue.Queue()
        self.pref = carica_pref()
        root.title("SmiDoc – smistatore di documenti")
        root.geometry("860x660")
        if WINDOWS:
            try:
                ttk.Style().theme_use("vista")      # aspetto nativo di Windows
            except tk.TclError:
                pass
        root.bind("<F1>", lambda e: self.aiuto())
        f = ttk.Frame(root, padding=12)
        f.pack(fill="both", expand=True)

        ttk.Label(f, text="1. File ricevuti dal debitore", font=("", 11, "bold")).pack(anchor="w")
        self.zona = tk.Label(f, text=("Trascina qui file o cartelle\n(foto, PDF, scansioni)" if DND
                                      else "Usa il pulsante «Aggiungi file…»"),
                             relief="groove", height=5, bg="#f4f6fa", fg="#444")
        self.zona.pack(fill="x", pady=4)
        if DND:
            self.zona.drop_target_register(DND_FILES)
            self.zona.dnd_bind("<<Drop>>", self.rilascio)
        r = ttk.Frame(f)
        r.pack(fill="x")
        ttk.Button(r, text="Aggiungi file…", command=self.scegli_file).pack(side="left")
        ttk.Button(r, text="Aggiungi cartella…", command=self.scegli_cartella).pack(side="left", padx=6)
        ttk.Button(r, text="Svuota elenco", command=self.svuota).pack(side="left")
        self.n_file = ttk.Label(r, text="nessun file")
        self.n_file.pack(side="left", padx=12)

        ttk.Label(f, text="2. Cartella della pratica", font=("", 11, "bold")).pack(anchor="w", pady=(14, 0))
        r = ttk.Frame(f)
        r.pack(fill="x", pady=4)
        self.pratica = tk.StringVar(value=self.pref.get("pratica", ""))
        ttk.Entry(r, textvariable=self.pratica).pack(side="left", fill="x", expand=True)
        ttk.Button(r, text="Sfoglia…", command=self.scegli_pratica).pack(side="left", padx=6)

        r = ttk.Frame(f)
        r.pack(fill="x", pady=(10, 4))
        self.prova = tk.BooleanVar(value=self.pref.get("prova", True))
        self.colore = tk.BooleanVar(value=self.pref.get("colore", False))
        self.ai = tk.BooleanVar(value=False)
        ttk.Checkbutton(r, text="Prova (non scrive nella pratica: all'avvio ti chiedo dove mettere i risultati)",
                        variable=self.prova).pack(anchor="w")
        ttk.Checkbutton(r, text="Mantieni i colori (timbri, firme)", variable=self.colore).pack(anchor="w")
        ttk.Checkbutton(r, text="Usa AI per le pagine non riconosciute (solo se attivata in categorie.toml)",
                        variable=self.ai).pack(anchor="w")

        r = ttk.Frame(f)
        r.pack(fill="x", pady=6)
        self.avvia = ttk.Button(r, text="3. Avvia smistamento", command=self.parti)
        self.avvia.pack(side="left")
        self.btn_riep = ttk.Button(r, text="Riepilogo ▾", command=self.menu_riepilogo)
        self.btn_riep.pack(side="left", padx=(6, 0))
        ttk.Button(r, text="Modifica categorie", command=lambda: self.apri(smidoc.QUI / "categorie.toml")).pack(side="left", padx=6)
        ttk.Button(r, text="? Aiuto", command=self.aiuto).pack(side="left")
        self.bar = ttk.Progressbar(r, mode="indeterminate", length=180)
        self.bar.pack(side="right")

        self.log = tk.Text(f, height=14, font=FONT_LOG, state="disabled")
        self.log.pack(fill="both", expand=True, pady=(6, 0))
        root.after(150, self.svuota_coda)

    # ---- raccolta file
    def aggiungi(self, percorsi):
        for p in percorsi:
            p = Path(p)
            if p.exists() and p not in self.file:
                self.file.append(p)
        self.n_file.config(text=f"{len(self.file)} elementi: " + ", ".join(x.name for x in self.file[:4])
                           + ("…" if len(self.file) > 4 else ""))

    def rilascio(self, ev):
        self.aggiungi(self.root.tk.splitlist(ev.data))

    def scegli_file(self):
        self.aggiungi(filedialog.askopenfilenames(title="File ricevuti"))

    def scegli_cartella(self):
        d = filedialog.askdirectory(title="Cartella con i file ricevuti")
        if d:
            self.aggiungi([d])

    def svuota(self):
        self.file = []
        self.n_file.config(text="nessun file")

    def scegli_pratica(self):
        d = filedialog.askdirectory(title="Cartella della pratica", initialdir=self.pratica.get() or str(Path.home()))
        if d:
            self.pratica.set(d)

    # ---- esecuzione
    def scrivi(self, testo):
        self.coda.put(testo)

    def svuota_coda(self):
        while not self.coda.empty():
            t = self.coda.get()
            if isinstance(t, tuple):        # fine lavoro
                self.fine(*t)
                continue
            self.log.config(state="normal")
            self.log.insert("end", t + "\n")
            self.log.see("end")
            self.log.config(state="disabled")
        self.root.after(150, self.svuota_coda)

    def parti(self):
        if not self.file:
            messagebox.showwarning("SmiDoc", "Aggiungi prima i file ricevuti.")
            return
        prova = self.prova.get()
        if not prova and not self.pratica.get():
            messagebox.showwarning("SmiDoc", "Scegli la cartella della pratica.")
            return
        dove_prova = None
        if prova:
            # in prova si chiede ogni volta dove creare la cartella dei risultati
            d = filedialog.askdirectory(
                title="Prova: dove creo la cartella con i risultati?",
                initialdir=self.pref.get("cartella_prova") or self.pratica.get() or str(Path.home()))
            if not d:
                return                       # annullato: non parte nulla
            dove_prova = Path(d)
        self.pref.update({"pratica": self.pratica.get(), "prova": prova, "colore": self.colore.get()})
        if dove_prova:
            self.pref["cartella_prova"] = str(dove_prova)
        salva_pref(self.pref)
        ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        # un'unica cartella di ingresso: se è stata data una sola cartella si usa quella,
        # altrimenti si copiano gli elementi in una cartella di appoggio
        if len(self.file) == 1 and self.file[0].is_dir():
            ingresso = self.file[0]
        else:
            ingresso = APPOGGIO / f"ingresso_{ts}"
            ingresso.mkdir(parents=True)
            for p in self.file:
                for q in ([p] if p.is_file() else sorted(x for x in p.iterdir() if x.is_file())):
                    dest = ingresso / q.name
                    i = 2
                    while dest.exists():
                        dest = ingresso / f"{q.stem}_{i}{q.suffix}"
                        i += 1
                    shutil.copy2(q, dest)
        pratica = (dove_prova / f"PROVA_SmiDoc_{ts}") if prova else Path(self.pratica.get())
        self.avvia.state(["disabled"])
        self.bar.start(12)
        threading.Thread(target=self.lavoro, args=(ingresso, pratica), daemon=True).start()

    def lavoro(self, ingresso, pratica):
        try:
            rie = smidoc.esegui(ingresso, pratica, prova=False, colore=self.colore.get(),
                                usa_ai=self.ai.get(), log=self.scrivi)
            self.coda.put((rie, None))
        except Exception as e:
            self.coda.put((None, e))

    def fine(self, riepilogo, errore):
        self.bar.stop()
        self.avvia.state(["!disabled"])
        if errore:
            messagebox.showerror("SmiDoc", f"Errore: {errore}")
            return
        self.svuota()
        self.pref["ultimo_riepilogo"] = str(riepilogo)
        salva_pref(self.pref)
        self.apri(riepilogo)

    # ---- riepilogo dei documenti analizzati
    def menu_riepilogo(self):
        ultimo = Path(self.pref.get("ultimo_riepilogo", ""))
        esiste = ultimo.is_file() if str(ultimo) not in ("", ".") else False
        m = tk.Menu(self.root, tearoff=0)
        stato = "normal" if esiste else "disabled"
        m.add_command(label="Visualizza l'ultimo riepilogo", state=stato, command=lambda: self.apri(ultimo))
        pdf = ultimo.with_suffix(".pdf")
        m.add_command(label="Apri l'ultimo riepilogo in PDF (stampa)",
                      state="normal" if esiste and pdf.is_file() else "disabled", command=lambda: self.apri(pdf))
        m.add_separator()
        m.add_command(label="Scegli un riepilogo precedente…", command=self.scegli_riepilogo)
        x = self.btn_riep.winfo_rootx()
        y = self.btn_riep.winfo_rooty() + self.btn_riep.winfo_height()
        m.tk_popup(x, y)

    def scegli_riepilogo(self):
        base = self.pratica.get()
        iniziale = Path(base) / "_SmiDoc" if base and (Path(base) / "_SmiDoc").is_dir() else Path(base or Path.home())
        f = filedialog.askopenfilename(title="Riepilogo da aprire", initialdir=str(iniziale),
                                       filetypes=[("Riepiloghi SmiDoc", "riepilogo_*.pdf riepilogo_*.html"),
                                                  ("Tutti i file", "*.*")])
        if f:
            self.apri(f)

    @staticmethod
    def apri(percorso):
        """Apre file o cartella con il programma predefinito del sistema."""
        if WINDOWS:
            os.startfile(str(percorso))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(percorso)])
        else:
            subprocess.Popen(["xdg-open", str(percorso)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # ---- guida
    def aiuto(self):
        """Finestra con la guida (testo in guida.md, modificabile)."""
        if getattr(self, "_guida", None) and self._guida.winfo_exists():
            self._guida.lift()
            return
        w = self._guida = tk.Toplevel(self.root)
        w.title("SmiDoc – Guida")
        w.geometry("760x640")
        t = tk.Text(w, wrap="word", padx=18, pady=14, relief="flat", font=("", 10), cursor="arrow")
        sb = ttk.Scrollbar(w, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        t.tag_configure("h1", font=("", 15, "bold"), spacing3=8)
        t.tag_configure("h2", font=("", 12, "bold"), spacing1=12, spacing3=4, foreground="#1f4e79")
        t.tag_configure("b", font=("", 10, "bold"))
        t.tag_configure("li", lmargin1=14, lmargin2=30)
        t.tag_configure("code", font=FONT_LOG, background="#eef1f5")
        try:
            righe = GUIDA.read_text(encoding="utf-8").splitlines()
        except OSError:
            righe = ["# Guida non trovata", f"Manca il file {GUIDA}"]
        for r in righe:
            if r.startswith("# "):
                t.insert("end", r[2:] + "\n", "h1")
                continue
            if r.startswith("## "):
                t.insert("end", r[3:] + "\n", "h2")
                continue
            base = ()
            if r.lstrip().startswith(("- ", "* ")) or r[:3].rstrip(".").isdigit():
                base = ("li",)
                if r.lstrip().startswith(("- ", "* ")):
                    r = "•  " + r.lstrip()[2:]
            # **grassetto** e `codice`
            for pezzo in __import__("re").split(r"(\*\*.+?\*\*|`.+?`)", r):
                if pezzo.startswith("**") and pezzo.endswith("**"):
                    t.insert("end", pezzo[2:-2], base + ("b",))
                elif pezzo.startswith("`") and pezzo.endswith("`"):
                    t.insert("end", pezzo[1:-1], base + ("code",))
                else:
                    t.insert("end", pezzo, base)
            t.insert("end", "\n")
        t.configure(state="disabled")
        ttk.Button(w, text="Chiudi", command=w.destroy).pack(pady=6)


def main():
    root = TkinterDnD.Tk() if DND else tk.Tk()
    Finestra(root)
    root.mainloop()


if __name__ == "__main__":
    main()
