#!/usr/bin/env python3
"""
SmiDoc - Smistatore di documenti (prototipo)

Prende i file così come arrivano dai debitori (foto, scansioni, PDF),
li ripulisce, capisce che documenti sono, divide i file che ne contengono
più d'uno, unisce i pezzi dello stesso documento e salva un PDF per ogni
documento nella sottocartella giusta della pratica.

Uso:
    smidoc.py CARTELLA_IN_ARRIVO CARTELLA_PRATICA [--prova] [--colore]

I file di ingresso non vengono mai modificati; nella pratica nessun file
esistente viene sovrascritto.
"""
import argparse
import datetime as dt
import html
import json
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np
import pymupdf
from PIL import Image, ImageOps

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:  # foto iPhone .heic non supportate, il resto funziona
    pass

# cartella del programma (con SmiDoc.exe è quella dell'eseguibile, dove stanno categorie.toml e guida.md)
QUI = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
EST_IMMAGINI = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp", ".tif", ".tiff", ".bmp"}
EST_PDF = {".pdf"}
DPI = 200                      # risoluzione dei PDF prodotti (adatta al deposito telematico)
LATO_MAX = int(11.7 * DPI)     # lato lungo massimo ≈ A4 a 200 dpi
QUALITA_JPEG = 70


# ============================================================ configurazione
@dataclass
class Tipo:
    nome: str
    sigla: str
    cartella: str
    parole: list
    forti: list


def norm(s: str) -> str:
    """minuscolo, senza accenti, apostrofi uniformi, spazi compattati"""
    s = s.replace("’", "'").replace("`", "'").lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", s)


def carica_config(percorso: Path):
    with open(percorso, "rb") as f:
        cfg = tomllib.load(f)
    cartelle = cfg["cartelle"]
    tipi = []
    for t in cfg.get("tipo", []):
        if t["cartella"] not in cartelle:
            sys.exit(f"Errore in {percorso.name}: il tipo «{t['nome']}» usa la cartella "
                     f"«{t['cartella']}» che non è tra le [cartelle].")
        tipi.append(Tipo(t["nome"], t["sigla"], t["cartella"],
                         [frase(p) for p in t.get("parole", [])],
                         [frase(p) for p in t.get("forti", [])]))
    return cartelle, tipi


def frase(p: str):
    """Espressione che trova la frase solo come parola intera (niente «retta» in «corretta»).
    Restituisce (regex, numero di parole): le frasi più lunghe pesano di più."""
    p = norm(p).strip()
    return re.compile(r"(?<![a-z0-9])" + re.escape(p) + r"(?![a-z0-9])"), len(p.split())


# ============================================================ modello dati
@dataclass
class Pagina:
    sorgente: Path
    n: int                      # numero di pagina nel file (da 1)
    tot_file: int               # pagine totali del file
    foto: bool                  # True se era una foto/scansione (non un PDF nativo)
    pdf_pagina: Path | None = None   # PDF a una pagina pronto (con testo ricercabile)
    nativo: tuple | None = None      # (file pdf, indice) se pagina PDF con testo
    anteprima: np.ndarray | None = None
    testo: str = ""
    tipo: Tipo | None = None
    punteggio: int = 0
    forte_in_testa: bool = False
    paginazione: tuple | None = None
    codici_fiscali: set = field(default_factory=set)
    interventi: list = field(default_factory=list)

    @property
    def etichetta(self):
        return f"{self.sorgente.name}" + (f" p.{self.n}" if self.tot_file > 1 else "")


@dataclass
class Documento:
    pagine: list
    tipo: Tipo | None = None
    note: list = field(default_factory=list)
    file_creato: Path | None = None


# ============================================================ pulizia immagini
def carica_immagine(percorso: Path) -> np.ndarray:
    im = ImageOps.exif_transpose(Image.open(percorso)).convert("RGB")
    return cv2.cvtColor(np.asarray(im), cv2.COLOR_RGB2BGR)


def _ordina_punti(q):
    q = q.reshape(4, 2).astype("float32")
    s, d = q.sum(1), np.diff(q, axis=1).ravel()
    return np.array([q[np.argmin(s)], q[np.argmin(d)], q[np.argmax(s)], q[np.argmax(d)]], "float32")


def trova_foglio(img):
    """Cerca il contorno del foglio (per togliere tavolo, tovaglia, mani).
    Restituisce i 4 vertici o None se il foglio occupa già tutta l'immagine."""
    h, w = img.shape[:2]
    k = 1000 / max(h, w)
    small = cv2.resize(img, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    area_tot = small.shape[0] * small.shape[1]
    candidati = []

    # 1) bordi netti
    gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    edges = cv2.dilate(cv2.Canny(gray, 40, 140), np.ones((3, 3), np.uint8), iterations=2)
    cnts, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:5]:
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(approx) == 4 and cv2.isContourConvex(approx) and cv2.contourArea(approx) > 0.2 * area_tot:
            candidati.append(approx)
            break

    # 2) la carta: zona poco colorata e non buia, compatta e al centro della foto.
    #    L'apertura con un elemento grande stacca i pezzi di sfondo chiari ma
    #    sottili o a scacchi (tovaglie, piastrelle) che toccano il foglio.
    hsv = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2HSV), (7, 7), 0)
    mask = ((hsv[:, :, 1] < 60) & (hsv[:, :, 2] > 90)).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))   # chiude le righe di testo
    lato = int(0.045 * max(small.shape[:2])) | 1
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (lato, lato)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask)
    if n > 1:
        cy, cx = small.shape[0] // 2, small.shape[1] // 2
        idx = lab[cy, cx] if lab[cy, cx] else 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        if stats[idx, cv2.CC_STAT_AREA] > 0.2 * area_tot:
            cnts, _ = cv2.findContours((lab == idx).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            hull = cv2.convexHull(max(cnts, key=cv2.contourArea))
            approx = cv2.approxPolyDP(hull, 0.02 * cv2.arcLength(hull, True), True)
            if len(approx) != 4:
                approx = cv2.boxPoints(cv2.minAreaRect(hull)).reshape(-1, 1, 2).astype(np.int32)
            candidati.insert(0, approx)    # preferito rispetto ai bordi

    if not candidati:
        return None
    q = candidati[0]
    if cv2.contourArea(q) > 0.93 * area_tot:   # il foglio riempie già la foto
        return None
    return _ordina_punti(q) / k


def raddrizza(img, q):
    tl, tr, br, bl = q
    larg = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
    alt = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    dst = np.array([[0, 0], [larg - 1, 0], [larg - 1, alt - 1], [0, alt - 1]], "float32")
    return cv2.warpPerspective(img, cv2.getPerspectiveTransform(q, dst), (larg, alt))


def sbianca_intrusi(img):
    """Dopo il ritaglio: sbianca ciò che entra dal bordo e non è carta (dita, mano,
    angoli di tovaglia). Non tocca timbri e firme, che stanno dentro il foglio."""
    h, w = img.shape[:2]
    hsv = cv2.cvtColor(cv2.GaussianBlur(img, (9, 9), 0), cv2.COLOR_BGR2HSV)
    # riferimento = colore tipico del foglio (anche se azzurrino o ingiallito)
    s_carta = float(np.median(hsv[:, :, 1]))
    v_carta = float(np.median(hsv[:, :, 2]))
    estraneo = ((hsv[:, :, 1] > s_carta + 50) | (hsv[:, :, 2] < min(70, v_carta * 0.4))).astype(np.uint8) * 255
    estraneo = cv2.morphologyEx(estraneo, cv2.MORPH_OPEN, np.ones((15, 15), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(estraneo)
    tolti = 0
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        tocca_bordo = x <= 2 or y <= 2 or x + bw >= w - 2 or y + bh >= h - 2
        if tocca_bordo and 0.004 * h * w < area < 0.30 * h * w:   # oltre il 30% è il foglio stesso
            m = cv2.dilate((lab == i).astype(np.uint8), np.ones((15, 15), np.uint8)).astype(bool)
            img[m] = 255
            tolti += 1
    return img, tolti


def rimuovi_ombre(img, colore=False):
    """Uniforma lo sfondo (via ombre e luce irregolare) e porta la carta a bianco."""
    def piano(p):
        bg = cv2.medianBlur(cv2.dilate(p, np.ones((7, 7), np.uint8)), 31)
        out = 255 - cv2.absdiff(p, bg)
        out = cv2.normalize(out, None, 0, 255, cv2.NORM_MINMAX)
        # livelli adattivi: carta bianca piena; l'inchiostro più chiaro presente
        # (anche se sbiadito) viene portato verso il nero
        nero = float(np.percentile(out, 0.5))
        nero = min(nero + 20, 200)
        lut = np.clip((np.arange(256) - nero) * 255.0 / max(240 - nero, 20), 0, 255).astype(np.uint8)
        return cv2.LUT(out, lut)
    if colore:
        return cv2.merge([piano(c) for c in cv2.split(img)])
    return piano(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))


WINDOWS = sys.platform.startswith("win")


def salva_img(percorso, img, parametri=None) -> bool:
    """Come cv2.imwrite, ma funziona anche con percorsi con lettere accentate (Windows)."""
    ok, buf = cv2.imencode(Path(percorso).suffix or ".png", img, parametri or [])
    if ok:
        Path(percorso).write_bytes(buf.tobytes())
    return ok


def trova_tesseract():
    """Percorso del programma Tesseract (OCR): su Linux è nel PATH, su Windows
    di solito in C:\\Program Files\\Tesseract-OCR. Si può forzare con SMIDOC_TESSERACT."""
    import os
    cand = [os.environ.get("SMIDOC_TESSERACT"), shutil.which("tesseract")]
    if WINDOWS:
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     os.environ.get("LOCALAPPDATA", "")):
            cand.append(str(Path(base) / "Tesseract-OCR" / "tesseract.exe"))
        cand.append(str(QUI / "Tesseract-OCR" / "tesseract.exe"))
    for c in cand:
        if c and Path(c).exists():
            return c
    raise RuntimeError("Tesseract (il programma che legge il testo) non è installato. "
                       "Su Windows lancia installa.bat; su Linux: sudo apt install tesseract-ocr tesseract-ocr-ita")


_TESS = None


_EXTRA = None


def _tessdata_extra():
    """Quale cartella di lingue usare. Se l'installazione di Tesseract ha già l'italiano
    si usa quella; altrimenti la cartella tessdata di SmiDoc, a cui serve anche pdf.ttf
    (il carattere con cui Tesseract crea i PDF ricercabili): se manca lo si copia
    dall'installazione di Tesseract."""
    global _EXTRA
    if _EXTRA is not None:
        return _EXTRA
    import glob
    sistema = [Path(_TESS).parent / "tessdata"] + [Path(p) for p in glob.glob("/usr/share/tesseract-ocr/*/tessdata")]
    locale = QUI / "tessdata"
    if any((d / "ita.traineddata").exists() for d in sistema) or not (locale / "ita.traineddata").exists():
        _EXTRA = []
        return _EXTRA
    if not (locale / "pdf.ttf").exists():
        for d in sistema:
            if (d / "pdf.ttf").exists():
                try:
                    shutil.copy2(d / "pdf.ttf", locale / "pdf.ttf")
                except OSError:
                    pass
                break
    _EXTRA = ["--tessdata-dir", str(locale)]
    return _EXTRA


def tesseract(args, timeout=180):
    global _TESS
    if _TESS is None:
        _TESS = trova_tesseract()
    extra = _tessdata_extra()
    r = subprocess.run([_TESS, *extra, *args], capture_output=True, text=True, timeout=timeout,
                       encoding="utf-8", errors="replace",
                       creationflags=0x08000000 if WINDOWS else 0)   # niente finestre nere su Windows
    return r.stdout + r.stderr


def orienta(img, tmp: Path):
    """Ruota la pagina se è girata di 90/180/270 gradi (rilevamento di Tesseract)."""
    f = tmp / "osd.png"
    salva_img(str(f), img)
    out = tesseract([str(f), "stdout", "--psm", "0"], timeout=60)
    rot = re.search(r"Rotate:\s*(\d+)", out)
    conf = re.search(r"Orientation confidence:\s*([\d.]+)", out)
    if not rot or not conf or float(conf.group(1)) < 2.0:
        return img, 0
    gradi = int(rot.group(1))
    giro = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}.get(gradi)
    return (cv2.rotate(img, giro), gradi) if giro is not None else (img, 0)


PAROLE_COMUNI = set("""di il la le lo che del della dei delle per con non sono data importo codice fiscale
comune totale euro pagamento via agenzia entrate contratto conto sig nato residente numero anno
banca credito debito saldo periodo imposta somma ufficio tribunale presente seguente nel nella
alla al dal dalla sul sulla come anche essere stato tra fra ai agli più ovvero oggetto spett""".split())


def qualita_testo(t: str) -> int:
    """Quante parole italiane comuni ci sono: misura grezza di un OCR riuscito."""
    return sum(1 for w in re.findall(r"[a-zàèéìòù]+", t.lower()) if w in PAROLE_COMUNI)


def ocr_completo(base: Path) -> str:
    """Un solo passaggio di Tesseract: testo per il riconoscimento + PDF ricercabile."""
    # opzioni passate con -c (non i file di configurazione "txt"/"pdf", che con una
    # cartella di lingue propria, come su Windows, possono mancare)
    tesseract([str(base) + ".jpg", str(base), "-l", "ita", "--dpi", str(DPI),
               "-c", "tessedit_create_txt=1", "-c", "tessedit_create_pdf=1"])
    f = Path(str(base) + ".txt")
    return f.read_text(errors="replace") if f.exists() else ""


def ocr_veloce(img, tmp: Path) -> str:
    k = min(1.0, 1400 / max(img.shape[:2]))
    f = tmp / "veloce.png"
    salva_img(str(f), cv2.resize(img, None, fx=k, fy=k, interpolation=cv2.INTER_AREA))
    return tesseract([str(f), "stdout", "-l", "ita", "--psm", "3"], timeout=90)


def limita(img):
    h, w = img.shape[:2]
    if max(h, w) <= LATO_MAX:
        return img
    k = LATO_MAX / max(h, w)
    return cv2.resize(img, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)


def pagina_da_immagine(img, sorgente, n, tot, tmp: Path, colore, da_foto):
    pg = Pagina(sorgente, n, tot, foto=True)
    if da_foto:
        q = trova_foglio(img)
        if q is not None:
            img = raddrizza(img, q)
            pg.interventi.append("ritaglio e prospettiva")
        img, tolti = sbianca_intrusi(img)
        if tolti:
            pg.interventi.append("rimossi elementi estranei dal bordo")
    img = rimuovi_ombre(img, colore)
    pg.interventi.append("pulizia sfondo/ombre")
    img, gradi = orienta(img, tmp)
    if gradi:
        pg.interventi.append(f"ruotata di {gradi}°")
    img = limita(img)
    base = tmp / f"p{abs(hash((str(sorgente), n)))}"
    salva_img(str(base) + ".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, QUALITA_JPEG])
    # un solo passaggio di Tesseract: testo per il riconoscimento + PDF ricercabile
    pg.testo = ocr_completo(base)
    if qualita_testo(pg.testo) < 12:
        # l'orientamento automatico non basta (foto di lato o capovolta, poco testo):
        # si provano le altre rotazioni e si tiene quella con il testo più sensato
        migliore, q_max = None, qualita_testo(pg.testo)
        for giro, gradi in ((cv2.ROTATE_90_CLOCKWISE, 90), (cv2.ROTATE_180, 180), (cv2.ROTATE_90_COUNTERCLOCKWISE, 270)):
            prova = cv2.rotate(img, giro)
            q = qualita_testo(ocr_veloce(prova, tmp))
            if q > q_max + 5:
                migliore, q_max = (prova, gradi), q
        if migliore:
            img = migliore[0]
            pg.interventi.append(f"ruotata di {migliore[1]}°")
            salva_img(str(base) + ".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, QUALITA_JPEG])
            pg.testo = ocr_completo(base)
    pg.pdf_pagina = Path(str(base) + ".pdf")
    pg.anteprima = img
    return pg


# ============================================================ lettura ingresso
def ordine_naturale(p: Path):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", p.name)]


def leggi_ingresso(cartella: Path, tmp: Path, colore: bool, log):
    pagine, scartati = [], []
    files = sorted((f for f in cartella.iterdir() if f.is_file() and not f.name.startswith(".")), key=ordine_naturale)
    for f in files:
        est = f.suffix.lower()
        try:
            if est in EST_IMMAGINI:
                log(f"  foto/immagine: {f.name}")
                pagine.append(pagina_da_immagine(carica_immagine(f), f, 1, 1, tmp, colore, da_foto=True))
            elif est in EST_PDF:
                doc = pymupdf.open(f)
                log(f"  PDF: {f.name} ({doc.page_count} pag.)")
                for i, page in enumerate(doc):
                    testo = page.get_text()
                    if len(testo.strip()) > 80:      # PDF "vero": si conserva la pagina originale
                        pg = Pagina(f, i + 1, doc.page_count, foto=False, nativo=(f, i), testo=testo)
                        pix = page.get_pixmap(dpi=60)
                        pg.anteprima = cv2.cvtColor(np.frombuffer(pix.samples, np.uint8).reshape(pix.h, pix.w, pix.n)[:, :, :3], cv2.COLOR_RGB2BGR)
                        pg.interventi.append("PDF originale conservato")
                        pagine.append(pg)
                    else:                             # PDF scansionato o foto dentro un PDF
                        pix = page.get_pixmap(dpi=DPI)
                        img = cv2.cvtColor(np.frombuffer(pix.samples, np.uint8).reshape(pix.h, pix.w, pix.n)[:, :, :3], cv2.COLOR_RGB2BGR)
                        pagine.append(pagina_da_immagine(img, f, i + 1, doc.page_count, tmp, colore, da_foto=True))
            else:
                scartati.append(f)
        except Exception as e:  # un file rovinato non deve fermare tutto
            log(f"  !! impossibile leggere {f.name}: {e}")
            scartati.append(f)
    return pagine, scartati


# ============================================================ riconoscimento
RE_PAG = re.compile(r"\bpag(?:ina|\.)?\s*(\d{1,3})\s*(?:di|/|of)\s*(\d{1,3})\b")
RE_CF = re.compile(r"\b[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]\b")


def classifica(pg: Pagina, tipi):
    t = norm(pg.testo)
    testa = t[:700]
    migliore, punti_max, forte_testa = None, 0, False
    for tipo in tipi:
        # frase tipica: 4 punti (+1 per ogni parola in più, le frasi lunghe sono più
        # specifiche) e +2 se è nella parte alta della pagina; parola indizio: 1 punto
        punti = sum(3 + n for rx, n in tipo.forti if rx.search(t))
        punti += sum(2 for rx, n in tipo.forti if rx.search(testa))
        punti += sum(1 for rx, n in tipo.parole if rx.search(t))
        if punti > punti_max:
            migliore, punti_max = tipo, punti
            forte_testa = any(rx.search(testa) for rx, n in tipo.forti)
    pg.tipo = migliore if punti_max >= 4 else None
    pg.punteggio = punti_max
    pg.forte_in_testa = forte_testa and pg.tipo is not None
    m = RE_PAG.search(t)
    if m and 1 <= int(m.group(1)) <= int(m.group(2)) <= 300:
        pg.paginazione = (int(m.group(1)), int(m.group(2)))
    pg.codici_fiscali = set(RE_CF.findall(pg.testo.upper().replace(" ", "")))


def nuovo_documento(doc: Documento, p: Pagina):
    """Decide se la pagina p apre un nuovo documento o continua quello corrente."""
    ultima = doc.pagine[-1]
    # 1) numerazione esplicita "pagina X di Y"
    if p.paginazione:
        if p.paginazione[0] == 1:
            return True, None
        if ultima.paginazione and p.paginazione[1] == ultima.paginazione[1] and p.paginazione[0] == ultima.paginazione[0] + 1:
            return False, "pagine consecutive per numerazione"
    # 2) intestatario diverso
    cf_doc = set().union(*(x.codici_fiscali for x in doc.pagine))
    if p.codici_fiscali and cf_doc and not (p.codici_fiscali & cf_doc):
        return True, None
    # 3) tipo di documento diverso
    if p.tipo and doc.tipo and p.tipo is not doc.tipo:
        return True, None
    # 4) stesso file: si continua
    if p.sorgente == ultima.sorgente:
        return False, None
    # 5) file diversi: si uniscono solo foto/scansioni singole dello stesso tipo (o non riconosciute)
    if p.foto and ultima.foto and p.tot_file == 1 and ultima.tot_file == 1:
        if p.tipo is doc.tipo and p.tipo is not None:
            if p.forte_in_testa and not p.paginazione:
                return True, None          # sembra la prima pagina di un altro documento dello stesso tipo
            return False, "unito: foto successive dello stesso tipo"
        if p.tipo is None and (incompleto(doc) or nomi_in_sequenza(ultima.sorgente, p.sorgente)):
            return False, "unito per vicinanza: pagina non riconosciuta subito dopo (da controllare)"
    return True, None


def incompleto(doc: Documento):
    """Il documento dichiara più pagine di quelle già raccolte ("pagina 2 di 4")."""
    pg = [p.paginazione for p in doc.pagine if p.paginazione]
    return bool(pg) and pg[-1][0] < pg[-1][1]


def nomi_in_sequenza(a: Path, b: Path):
    """Foto scattate una dopo l'altra: stesso nome con numero finale +1
    (es. IMG-20261003-WA0011 e IMG-20261003-WA0012, scan_001 e scan_002)."""
    ma, mb = re.match(r"(.*?)(\d+)\D*$", a.stem), re.match(r"(.*?)(\d+)\D*$", b.stem)
    return bool(ma and mb and ma.group(1) == mb.group(1) and int(mb.group(2)) - int(ma.group(2)) == 1)


def raggruppa(pagine):
    docs = []
    for p in pagine:
        if docs:
            nuovo, motivo = nuovo_documento(docs[-1], p)
            if not nuovo:
                docs[-1].pagine.append(p)
                if motivo:
                    docs[-1].note.append(f"{p.etichetta}: {motivo}")
                if docs[-1].tipo is None and p.tipo:
                    docs[-1].tipo = p.tipo
                continue
        docs.append(Documento([p], tipo=p.tipo))
    for d in docs:
        if d.tipo is None:
            d.note.append("tipo non riconosciuto: da verificare")
    return docs


# ============================================================ uscita
RE_DATA = re.compile(r"\b(\d{1,2})[/.-](\d{1,2})[/.-](20\d{2}|19\d{2})\b")


MESI = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio",
        "agosto", "settembre", "ottobre", "novembre", "dicembre"]
RE_MESE = re.compile(r"\b(" + "|".join(MESI) + r")\s+(20\d{2})\b")
RE_NASCITA = re.compile(r"(nat[oa]|nascita|nato/a)\b[^\n]{0,30}$")
RE_BUONA = re.compile(r"(rilasciat\w*|rilascio|emess\w*|\bin data|\bdata:|\bli|\bli'|\bdel|[a-z]{3},)\s*$")
RE_FINE = re.compile(r"\b(al|fino al|a tutto il|saldo finale)\s*$")


def data_documento(doc: Documento):
    """Data da mettere nel nome del file: quella di rilascio/emissione o di fine
    periodo, mai quella di nascita. In mancanza, il periodo «mese anno»."""
    oggi = dt.date.today()
    candidati = []   # (punti, data)
    for p in doc.pagine:
        t = norm(p.testo)
        for m in RE_DATA.finditer(t):
            try:
                d = dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except ValueError:
                continue
            prima = t[max(0, m.start() - 45):m.start()]
            if RE_NASCITA.search(prima) or d > oggi + dt.timedelta(days=60) or d.year < 1990:
                continue
            punti = 1 + (3 if RE_BUONA.search(prima) else 0) + (2 if RE_FINE.search(prima) else 0)
            candidati.append((punti, d))
    if candidati:
        return max(candidati)[1].isoformat()     # a parità di punti vince la più recente
    for p in doc.pagine:
        m = RE_MESE.search(norm(p.testo))
        if m:
            return f"{m.group(2)}-{MESI.index(m.group(1)) + 1:02d}"
    return None


def nome_libero(cartella: Path, base: str) -> Path:
    f = cartella / f"{base}.pdf"
    i = 2
    while f.exists():
        f = cartella / f"{base}_{i}.pdf"
        i += 1
    return f


def scrivi_documento(doc: Documento, radice: Path, cartelle):
    chiave = doc.tipo.cartella if doc.tipo else "da_verificare"
    dest = radice / cartelle[chiave]
    dest.mkdir(parents=True, exist_ok=True)
    sigla = doc.tipo.sigla if doc.tipo else "Documento"
    data = data_documento(doc)
    out = nome_libero(dest, f"{data}_{sigla}" if data else sigla)
    pdf = pymupdf.open()
    aperti = {}
    for p in doc.pagine:
        if p.nativo:
            src = aperti.setdefault(p.nativo[0], pymupdf.open(p.nativo[0]))
            pdf.insert_pdf(src, from_page=p.nativo[1], to_page=p.nativo[1])
        elif p.pdf_pagina and p.pdf_pagina.exists() and p.pdf_pagina.stat().st_size > 0:
            with pymupdf.open(p.pdf_pagina) as one:
                pdf.insert_pdf(one)
        elif p.pdf_pagina and p.pdf_pagina.with_suffix(".jpg").exists():
            # ripiego: Tesseract non ha prodotto il PDF ricercabile -> pagina come sola immagine
            jpg = p.pdf_pagina.with_suffix(".jpg")
            h, w = p.anteprima.shape[:2] if p.anteprima is not None else (2339, 1654)
            pg = pdf.new_page(width=w * 72 / DPI, height=h * 72 / DPI)
            pg.insert_image(pg.rect, filename=str(jpg))
            p.interventi.append("PDF senza testo ricercabile")
    if pdf.page_count == 0:
        pdf.close()
        for s in aperti.values():
            s.close()
        raise RuntimeError(f"nessuna pagina utilizzabile per {', '.join(p.etichetta for p in doc.pagine)}")
    pdf.set_metadata({"title": doc.tipo.nome if doc.tipo else "Documento da verificare",
                      "creator": "SmiDoc"})
    pdf.save(out, garbage=4, deflate=True)
    pdf.close()
    for s in aperti.values():
        s.close()
    doc.file_creato = out


def scrivi_riepilogo(docs, scartati, radice: Path, cartella_in: Path, ts: str):
    cart = radice / "_SmiDoc"
    (cart / "anteprime").mkdir(parents=True, exist_ok=True)
    righe = []
    for i, d in enumerate(docs, 1):
        a = d.pagine[0].anteprima
        thumb = ""
        if a is not None:
            k = 220 / max(a.shape[:2])
            nome = f"{ts}_{i:02d}.jpg"
            salva_img(str(cart / "anteprime" / nome), cv2.resize(a, None, fx=k, fy=k, interpolation=cv2.INTER_AREA))
            thumb = f'<img src="anteprime/{nome}">'
        rel = Path("..") / d.file_creato.relative_to(radice)
        sorg = "<br>".join(html.escape(f"{p.etichetta} – " + ", ".join(p.interventi)) for p in d.pagine)
        stato = "ok" if d.tipo and not any("vicinanza" in n for n in d.note) else "verifica"
        righe.append(f"""<tr class="{stato}"><td>{thumb}</td>
<td><a href="{html.escape(str(rel))}">{html.escape(d.file_creato.name)}</a><br><small>{html.escape(d.file_creato.parent.name)}</small></td>
<td>{html.escape(d.tipo.nome) if d.tipo else '<b>non riconosciuto</b>'}</td><td>{len(d.pagine)}</td>
<td><small>{sorg}</small></td><td><small>{'<br>'.join(html.escape(n) for n in d.note)}</small></td></tr>""")
    scart = "".join(f"<li>{html.escape(f.name)}</li>" for f in scartati) or "<li>nessuno</li>"
    quando = dt.datetime.strptime(ts, "%Y%m%d_%H%M%S").strftime("%d/%m/%Y %H:%M")
    n_ver = sum(1 for r in righe if 'class="verifica"' in r)
    per_cartella = {}
    for d in docs:
        per_cartella[d.file_creato.parent.name] = per_cartella.get(d.file_creato.parent.name, 0) + 1
    sintesi = ", ".join(f"{html.escape(k)}: {v}" for k, v in sorted(per_cartella.items()))
    testa = f"""<h2>SmiDoc – riepilogo dei documenti analizzati</h2>
<p>Pratica: <b>{html.escape(radice.name)}</b> &nbsp;·&nbsp; Elaborazione del {quando}<br>
<small>Ingresso: {html.escape(str(cartella_in))}<br>Destinazione: {html.escape(str(radice))}</small></p>
<p><b>{len(docs)}</b> documenti creati, <b>{n_ver}</b> da controllare (righe in giallo).<br><small>{sintesi}</small></p>"""
    tabella = (f"<table><tr><th>Anteprima</th><th>File creato</th><th>Tipo</th><th>Pag.</th>"
               f"<th>Provenienza e trattamenti</th><th>Note</th></tr>{''.join(righe)}</table>"
               f"<h3>File non elaborati</h3><ul>{scart}</ul>")
    pagina = f"""<!DOCTYPE html><html lang="it"><head><meta charset="utf-8"><title>SmiDoc – riepilogo {quando}</title>
<style>body{{font-family:sans-serif;margin:24px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccc;padding:6px;vertical-align:top}}
tr.verifica{{background:#fff4d6}}img{{border:1px solid #999}}th{{background:#eee;text-align:left}}
.pulsanti{{float:right}} .pulsanti button{{font-size:14px;padding:6px 14px;margin-left:6px;cursor:pointer}}
@media print{{ .pulsanti{{display:none}} body{{margin:0}} tr{{page-break-inside:avoid}}
  tr.verifica{{-webkit-print-color-adjust:exact;print-color-adjust:exact}} @page{{size:A4 landscape;margin:12mm}} }}</style></head><body>
<div class="pulsanti"><button onclick="window.print()">🖨 Stampa / Salva PDF</button></div>
{testa}{tabella}</body></html>"""
    f = cart / f"riepilogo_{ts}.html"
    f.write_text(pagina, encoding="utf-8")
    try:
        riepilogo_pdf(testa + tabella, cart, cart / f"riepilogo_{ts}.pdf")
    except Exception as e:     # il PDF è un di più: se fallisce resta l'HTML
        print(f"  (riepilogo PDF non creato: {e})")
    return f


def riepilogo_pdf(corpo_html: str, cartella: Path, uscita: Path):
    """Versione PDF del riepilogo (A4 orizzontale), da stampare o archiviare."""
    css = """body{font-family:sans-serif;font-size:8pt} h2{font-size:13pt} h3{font-size:10pt}
table{border-collapse:collapse;width:100%} td,th{border:1px solid #999;padding:3px;vertical-align:top}
th{background-color:#e6e6e6;text-align:left} tr.verifica td{background-color:#fff0c2}
img{width:70px} a{color:#000;text-decoration:none} small{font-size:7pt}"""
    # i link ai PDF non servono su carta
    corpo = re.sub(r"<a [^>]*>(.*?)</a>", r"\1", corpo_html)
    corpo = corpo.replace("<img ", '<img height="62" ')   # anteprime piccole: più righe per pagina
    story = pymupdf.Story(html=corpo, user_css=css, archive=pymupdf.Archive(str(cartella)))
    foglio = pymupdf.paper_rect("a4-l")
    area = foglio + (30, 30, -30, -40)
    writer = pymupdf.DocumentWriter(str(uscita))
    n, altro = 0, True
    while altro:
        n += 1
        dev = writer.begin_page(foglio)
        altro, _ = story.place(area)
        story.draw(dev)
        writer.end_page()
    writer.close()
    # numero di pagina in basso
    with pymupdf.open(uscita) as doc:
        for i, pg in enumerate(doc, 1):
            pg.insert_text((foglio.width - 110, foglio.height - 18), f"SmiDoc – pag. {i}/{doc.page_count}", fontsize=7)
        doc.saveIncr()


# ============================================================ main
def esegui(ingresso: Path, pratica: Path, prova=False, colore=False, usa_ai=False,
           config: Path = QUI / "categorie.toml", log=print) -> Path:
    """Esegue tutto il lavoro; restituisce il percorso del riepilogo HTML.
    Usata sia dalla riga di comando sia dalla finestra (smidoc_finestra.py)."""
    if not ingresso.is_dir():
        raise ValueError(f"Cartella di ingresso inesistente: {ingresso}")
    cartelle, tipi = carica_config(config)
    with open(config, "rb") as f:
        cfg_tutto = tomllib.load(f)
    cfg_ai = cfg_tutto.get("ai", {})
    crea_tutte = cfg_tutto.get("opzioni", {}).get("crea_tutte_le_cartelle", False)
    ai_attiva = usa_ai and cfg_ai.get("attiva", False)
    if usa_ai and not ai_attiva:
        log("NB: AI richiesta ma spenta in categorie.toml ([ai] attiva = false): uso solo le regole locali.")
    if ai_attiva:
        import ai_claude
        if not ai_claude.disponibile():
            log("NB: pacchetto 'anthropic' non installato: uso solo le regole locali.")
            ai_attiva = False
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    if prova:   # prova=True: accanto all'ingresso; prova=cartella: dentro la cartella indicata
        radice = (prova if isinstance(prova, Path) else ingresso.parent) / f"PROVA_SmiDoc_{ts}"
    else:
        radice = pratica
    radice.mkdir(parents=True, exist_ok=True)
    log(f"Ingresso: {ingresso}\nDestinazione: {radice}")
    if crea_tutte:   # struttura standard del Gestore, anche le cartelle che restano vuote
        for chiave, nome in cartelle.items():
            if chiave != "da_verificare":
                (radice / nome).mkdir(exist_ok=True)

    tmp = Path(tempfile.mkdtemp(prefix="smidoc_"))
    try:
        log("1) Lettura e pulizia delle pagine…")
        pagine, scartati = leggi_ingresso(ingresso, tmp, colore, log)
        log(f"2) Riconoscimento di {len(pagine)} pagine…")
        per_sigla = {t.sigla: t for t in tipi}
        for p in pagine:
            classifica(p, tipi)
            if ai_attiva and p.tipo is None and p.anteprima is not None:
                try:
                    sigla, motivo = ai_claude.classifica_pagina(p.anteprima, p.testo, tipi, cfg_ai.get("modello", "claude-opus-5-5"))
                    if sigla in per_sigla:
                        p.tipo = per_sigla[sigla]
                        p.interventi.append(f"riconosciuta dall'AI ({motivo})")
                except Exception as e:  # rete, credenziali, quota: si prosegue senza AI
                    log(f"  AI non disponibile per {p.etichetta}: {e}")
            log(f"  {p.etichetta}: {p.tipo.nome if p.tipo else '?'} (punti {p.punteggio})"
                + (f", pag. {p.paginazione[0]}/{p.paginazione[1]}" if p.paginazione else ""))
        docs = raggruppa(pagine)
        log(f"3) Creazione di {len(docs)} documenti…")
        riusciti = []
        for d in docs:
            try:
                scrivi_documento(d, radice, cartelle)
            except Exception as e:     # un documento problematico non ferma gli altri
                log(f"  !! documento non creato: {e}")
                scartati.extend(sorted({p.sorgente for p in d.pagine}))
                continue
            riusciti.append(d)
            log(f"  -> {d.file_creato.relative_to(radice)}  ({len(d.pagine)} pag.)")
        docs = riusciti
        rie = scrivi_riepilogo(docs, scartati, radice, ingresso, ts)
        (radice / "_SmiDoc" / f"registro_{ts}.json").write_text(json.dumps([
            {"file": str(d.file_creato.relative_to(radice)), "tipo": d.tipo.nome if d.tipo else None,
             "pagine": [{"origine": p.etichetta, "punti": p.punteggio, "testo_letto": p.testo[:1500]}
                        for p in d.pagine], "note": d.note} for d in docs],
            ensure_ascii=False, indent=1), encoding="utf-8")
        log(f"\nRiepilogo da controllare: {rie}")
        return rie
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser(description="SmiDoc – smistatore di documenti (prototipo)")
    ap.add_argument("ingresso", type=Path, help="cartella con i file ricevuti")
    ap.add_argument("pratica", type=Path, help="cartella della pratica del debitore")
    ap.add_argument("--prova", nargs="?", const=True, default=False, type=Path, metavar="CARTELLA",
                    help="non scrive nella pratica: crea la cartella dei risultati dentro CARTELLA "
                         "(se omessa, accanto alla cartella di ingresso)")
    ap.add_argument("--colore", action="store_true", help="conserva i colori (timbri, firme colorate)")
    ap.add_argument("--ai", action="store_true",
                    help="usa Claude per le pagine non riconosciute (solo se attivata in categorie.toml)")
    ap.add_argument("--config", type=Path, default=QUI / "categorie.toml")
    a = ap.parse_args()
    try:
        esegui(a.ingresso, a.pratica, a.prova, a.colore, a.ai, a.config)
    except ValueError as e:
        sys.exit(str(e))


if __name__ == "__main__":
    main()
