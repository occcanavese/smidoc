# SmiDoc – smistatore di documenti (prototipo)

Prende i file dei debitori così come arrivano (foto WhatsApp, scansioni, PDF accorpati o spezzati) e:

1. **ripulisce** ogni pagina: ritaglio del foglio, prospettiva raddrizzata, via tovaglia, dita e ombre, rotazione corretta;
2. **riconosce** il tipo di documento leggendo il testo (OCR in italiano);
3. **divide** i file che contengono più documenti e **unisce** le foto che sono pagine dello stesso documento;
4. salva **un PDF per documento**, leggero e con testo ricercabile, nella sottocartella giusta della pratica,
   secondo lo schema del Gestore (ACI PRA, ANAGRAFE, ANAGRAFE RAPPORTI FINANZIARI, ATTIVO, BANCHE DATI,
   CANCELLERIA ESEC. MOB. IMMOB, CASELLARIO e CARICHI, … MASSA PASSIVA, VISURA CATASTALE, VISURA STORICA CCIAA;
   più `_DA_VERIFICARE` per ciò che non riconosce). Alla prima elaborazione crea tutta la struttura;
5. scrive un **riepilogo** (`_SmiDoc/riepilogo_….html`) con anteprime e note: le righe in giallo vanno controllate.

Regole fisse: i file di ingresso non vengono mai modificati e nella pratica non si sovrascrive nulla
(se il nome esiste si aggiunge `_2`, `_3`…).

## Come si usa

- **Finestra**: menu applicazioni → *SmiDoc*, oppure `~/smistatore-documenti/smidoc`.
  Trascina i file, scegli la pratica, premi *Avvia*. Con la casella *Prova* la pratica non viene toccata: all'avvio SmiDoc chiede in quale cartella
  creare `PROVA_SmiDoc_<data_ora>` con i risultati (ricorda l'ultima scelta).
- **Riga di comando**:
  `~/smistatore-documenti/smidoc CARTELLA_IN_ARRIVO CARTELLA_PRATICA [--prova [CARTELLA]] [--colore] [--ai]`
  (con `--prova CARTELLA` i risultati vanno in quella cartella; con `--prova` da solo, accanto all'ingresso)

## Categorie

Tutto in `categorie.toml`: nomi delle cartelle, tipi di documento, frasi che li riconoscono.
Si modifica e si integra con un editor di testo (pulsante *Modifica categorie* nella finestra).

## AI (facoltativa, spenta)

`ai_claude.py` manda a Claude **solo le pagine non riconosciute**. Per attivarla:
`[ai] attiva = true` in `categorie.toml`, `.venv/bin/pip install anthropic`, credenziali API, e opzione `--ai`.
Da decidere con il Gestore (privacy/GDPR, costo a consumo).

## Prove

- `prove/genera_casi.py` crea i tre esempi del Gestore (foto storta con mano e tovaglia, PDF con 3 documenti, estratto conto in 4 foto).

## Installazione su Windows 10/11

1. Scompatta `SmiDoc-Windows.zip` in una cartella stabile, per esempio `C:\SmiDoc` (meglio un percorso senza spazi).
2. Doppio clic su `windows\installa.bat`. Lo script installa, se mancano:
   - Python 3.12;
   - le librerie;
   - Tesseract OCR con la lingua italiana.

   Poi crea l'icona **SmiDoc** sul desktop. Serve Internet; winget può chiedere conferme.
3. Avvia SmiDoc dall'icona o con `SmiDoc.bat`. La guida è nel pulsante **? Aiuto** (o tasto F1).

Facoltativo: `windows\crea_exe.bat` genera `dist\SmiDoc\SmiDoc.exe`, una cartella da copiare su altri PC senza Python.
Su quei PC serve comunque Tesseract.
