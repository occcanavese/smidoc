@echo off
rem SmiDoc - installazione (doppio clic)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installa.ps1"
pause
