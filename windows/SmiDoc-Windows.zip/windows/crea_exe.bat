@echo off
rem Facoltativo: crea dist\SmiDoc\SmiDoc.exe (cartella da copiare su altri PC Windows,
rem che non avranno bisogno di Python; serve comunque Tesseract installato).
cd /d "%~dp0.."
".venv\Scripts\python.exe" -m pip install --quiet pyinstaller
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name SmiDoc ^
  --collect-all tkinterdnd2 --collect-all pillow_heif smidoc_finestra.py
copy /y categorie.toml dist\SmiDoc\ >nul
copy /y guida.md dist\SmiDoc\ >nul
xcopy /e /i /y tessdata dist\SmiDoc\tessdata >nul
echo.
echo Pronto: dist\SmiDoc\SmiDoc.exe
pause
