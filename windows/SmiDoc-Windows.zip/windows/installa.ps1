# =====================================================================
#  SmiDoc - installazione su Windows 10/11
#  Lanciare con doppio clic su installa.bat (non serve essere amministratori,
#  ma winget potrebbe chiedere conferma per installare Python e Tesseract).
# =====================================================================
$ErrorActionPreference = "Stop"
$App = Split-Path -Parent $PSScriptRoot          # cartella principale di SmiDoc
Set-Location $App
Write-Host "== Installazione di SmiDoc in $App ==" -ForegroundColor Cyan

function Trova-Python {
    foreach ($c in @("py -3.12", "py -3.13", "py -3.11", "python")) {
        try {
            $v = & cmd /c "$c --version" 2>$null
            if ($LASTEXITCODE -eq 0 -and $v -match "Python 3\.(1[1-9])") { return $c }
        } catch {}
    }
    return $null
}

# 1) Python
$py = Trova-Python
if (-not $py) {
    Write-Host "1/4 Installo Python 3.12..." -ForegroundColor Yellow
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "User") + ";" + [Environment]::GetEnvironmentVariable("Path", "Machine")
    $py = Trova-Python
    if (-not $py) { throw "Python non trovato dopo l'installazione: chiudi e rilancia installa.bat." }
} else { Write-Host "1/4 Python presente ($py)" -ForegroundColor Green }

# 2) Ambiente e librerie
Write-Host "2/4 Preparo l'ambiente e installo le librerie (qualche minuto)..." -ForegroundColor Yellow
if (-not (Test-Path ".venv\Scripts\python.exe")) { & cmd /c "$py -m venv .venv" }
& ".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
& ".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet
if ($LASTEXITCODE -ne 0) { throw "Installazione delle librerie non riuscita." }

# 3) Tesseract (il programma che legge il testo) + lingua italiana
$tess = @("$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "$env:LOCALAPPDATA\Tesseract-OCR\tesseract.exe", "$env:LOCALAPPDATA\Programs\Tesseract-OCR\tesseract.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $tess) {
    Write-Host "3/4 Installo Tesseract OCR..." -ForegroundColor Yellow
    winget install -e --id UB-Mannheim.TesseractOCR --accept-package-agreements --accept-source-agreements
} else { Write-Host "3/4 Tesseract presente ($tess)" -ForegroundColor Green }
New-Item -ItemType Directory -Force -Path "tessdata" | Out-Null
foreach ($l in @("ita", "osd", "eng")) {
    if (-not (Test-Path "tessdata\$l.traineddata")) {
        Write-Host "    scarico la lingua $l..."
        Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$l.traineddata" -OutFile "tessdata\$l.traineddata"
    }
}
# carattere usato da Tesseract per creare i PDF con testo ricercabile
if (-not (Test-Path "tessdata\pdf.ttf")) {
    $src = @("$env:ProgramFiles\Tesseract-OCR\tessdata\pdf.ttf", "$env:LOCALAPPDATA\Programs\Tesseract-OCR\tessdata\pdf.ttf") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if ($src) { Copy-Item $src "tessdata\pdf.ttf" }
    else { Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/tesseract-ocr/tesseract/raw/main/tessdata/pdf.ttf" -OutFile "tessdata\pdf.ttf" }
}

# 4) Icona sul desktop
Write-Host "4/4 Creo l'icona SmiDoc sul desktop..." -ForegroundColor Yellow
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut([Environment]::GetFolderPath("Desktop") + "\SmiDoc.lnk")
$lnk.TargetPath = "$App\.venv\Scripts\pythonw.exe"
$lnk.Arguments = "`"$App\smidoc_finestra.py`""
$lnk.WorkingDirectory = $App
$lnk.Description = "SmiDoc - smistatore di documenti"
$lnk.Save()

Write-Host ""
Write-Host "Fatto! Avvia SmiDoc dall'icona sul desktop (o con SmiDoc.bat)." -ForegroundColor Green
