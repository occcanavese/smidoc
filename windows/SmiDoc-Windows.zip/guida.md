# SmiDoc – guida rapida

SmiDoc prende i documenti che ci mandano i debitori **così come arrivano** (foto col telefono, scansioni storte, PDF con più documenti dentro, documenti spezzati in più foto) e li trasforma in **PDF puliti, uno per documento**, già messi nella cartella giusta della pratica.

## Cosa fa, in breve

- **Pulisce le foto**: ritaglia il foglio, lo raddrizza, toglie tovaglia, dita, ombre; gira le pagine capovolte.
- **Riconosce il documento** leggendo il testo (carta d'identità, busta paga, estratto conto, CRIF, visura PRA…).
- **Divide** un file che contiene più documenti e **unisce** le foto che sono pagine dello stesso documento.
- **Salva un PDF per documento**, leggero e con il testo ricercabile, adatto al deposito telematico.
- **Archivia** ogni PDF nella sottocartella della pratica (ANAGRAFE, ATTIVO, MASSA PASSIVA, BANCHE DATI, ACI PRA, ISEE, SPESE SOST.NUCLEO…).

## Come si usa (3 passi)

1. **File ricevuti**: trascina nel riquadro grigio le foto, i PDF o un'intera cartella. In alternativa usa **Aggiungi file…** o **Aggiungi cartella…**. Si possono mescolare file di tipi diversi.
2. **Cartella della pratica**: con **Sfoglia…** scegli la cartella del debitore. SmiDoc la ricorda per la volta successiva.
3. Premi **Avvia smistamento**. Nel riquadro in basso vedi l'avanzamento; alla fine si apre da solo il **riepilogo**.

## La modalità Prova

Con la casella **Prova** spuntata la pratica **non viene toccata**: all'avvio SmiDoc chiede in quale cartella mettere i risultati e crea lì una cartella `PROVA_SmiDoc_data_ora`. Usala le prime volte, o quando vuoi vedere il risultato prima di archiviare davvero.

Quando sei soddisfatto, togli la spunta e rilancia: i PDF finiscono direttamente nelle cartelle della pratica.

## Il riepilogo: da controllare sempre

Al termine si apre una pagina con l'elenco dei documenti creati: anteprima, nome del file, cartella, tipo riconosciuto, da quali file e pagine proviene, e cosa è stato fatto (ritaglio, rotazione…).

- Le righe in **giallo** sono da controllare: documento non riconosciuto o pagine unite "per vicinanza".
- I documenti non riconosciuti finiscono nella cartella **_DA_VERIFICARE**: spostali tu nella cartella giusta.
- Il riepilogo resta salvato nella pratica, cartella `_SmiDoc`, in due versioni: **pagina** (HTML) e **PDF** (A4 orizzontale, pronto da stampare o allegare).
- Per rivederlo in seguito usa il pulsante **Riepilogo ▾**:
  - **Visualizza l'ultimo riepilogo**: apre la pagina; in alto a destra c'è il pulsante **Stampa / Salva PDF**;
  - **Apri l'ultimo riepilogo in PDF (stampa)**: apre il PDF, da stampare o archiviare;
  - **Scegli un riepilogo precedente…**: per riaprire quello di un'elaborazione passata (cartella `_SmiDoc` della pratica).

## Nomi dei file

Ogni PDF prende il nome **data_tipo**, ad esempio `2026-09-15_Certificato-residenza.pdf` o `2026-08_Busta-paga.pdf`. La data è quella di rilascio o di fine periodo, mai quella di nascita. Se un file con lo stesso nome esiste già, SmiDoc **non lo sovrascrive** e aggiunge `_2`, `_3`…

## Cosa SmiDoc non fa mai

- **Non modifica né cancella** i file ricevuti: lavora su copie.
- **Non sovrascrive** i file già presenti nella pratica.
- **Non invia nulla** su Internet (salvo l'opzione AI, spenta, vedi sotto).

## Le altre opzioni

- **Mantieni i colori**: utile per documenti con timbri o firme a colori. Senza spunta i PDF sono in scala di grigi, più leggeri.
- **Usa AI per le pagine non riconosciute**: oggi è **spenta**. Se un giorno verrà attivata, le sole pagine che SmiDoc non riconosce verrebbero inviate a un servizio di intelligenza artificiale (Claude) per classificarle. Va prima valutata la privacy.
- **Modifica categorie**: apre il file `categorie.toml`, dove sono scritte le cartelle e le frasi che servono a riconoscere ogni tipo di documento. Si può modificare con un qualsiasi editor di testo: per esempio aggiungere una frase a un tipo, o spostare un tipo in un'altra cartella.

## Consigli per buoni risultati

- Foto **dall'alto**, con il foglio intero e ben illuminato. Lo sfondo scuro aiuta.
- Più pagine dello stesso documento: meglio se le foto sono **in ordine** e mandate insieme (es. WA0011, WA0012…).
- Documenti molto sbiaditi o scritti a mano possono non essere riconosciuti: finiranno in _DA_VERIFICARE.

## Se qualcosa non va

- **"Tesseract non è installato"**: manca il programma che legge il testo: rilancia lo script di installazione dalla cartella di SmiDoc (`installa-linux.sh` su Linux, `windows\installa.bat` su Windows).
- **Il trascinamento non funziona**: usa i pulsanti Aggiungi file… / Aggiungi cartella….
- **Un documento è nella cartella sbagliata**: spostalo a mano; se succede spesso, segnalalo per aggiornare `categorie.toml`.

Tasto rapido: **F1** apre questa guida.
