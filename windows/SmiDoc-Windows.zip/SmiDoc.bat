@echo off
rem Avvio di SmiDoc su Windows (finestra, senza console)
cd /d "%~dp0"
start "" ".venv\Scripts\pythonw.exe" "smidoc_finestra.py"
