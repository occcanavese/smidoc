"""
SmiDoc - riconoscimento con AI (Claude API), FACOLTATIVO e SPENTO di default.

Viene usato solo se:
  * in categorie.toml la sezione [ai] ha  attiva = true, e
  * SmiDoc è lanciato con l'opzione --ai (o la casella "Usa AI" nella finestra), e
  * è installato il pacchetto `anthropic` e ci sono credenziali (ANTHROPIC_API_KEY
    oppure un profilo creato con `ant auth login`).

Alla AI vengono mandate SOLO le pagine che le regole locali non hanno saputo
riconoscere (immagine ridotta + testo OCR). Prima di attivarlo va valutato il
profilo privacy/GDPR con il Gestore: sono dati personali e finanziari.
"""
import base64
import json

import cv2


def disponibile():
    try:
        import anthropic  # noqa: F401
        return True
    except ImportError:
        return False


def classifica_pagina(img, testo_ocr, tipi, modello="claude-opus-5-5"):
    """Restituisce (sigla_tipo | None, motivazione). `tipi` è la lista dei Tipo di categorie.toml."""
    import anthropic

    k = min(1.0, 1568 / max(img.shape[:2]))
    ok, buf = cv2.imencode(".jpg", cv2.resize(img, None, fx=k, fy=k, interpolation=cv2.INTER_AREA),
                           [cv2.IMWRITE_JPEG_QUALITY, 80])
    if not ok:
        return None, "immagine non codificabile"
    elenco = "\n".join(f"- {t.sigla}: {t.nome}" for t in tipi)
    schema = {
        "type": "object",
        "properties": {
            "sigla": {"type": "string", "enum": [t.sigla for t in tipi] + ["NESSUNO"]},
            "motivazione": {"type": "string"},
        },
        "required": ["sigla", "motivazione"],
        "additionalProperties": False,
    }
    client = anthropic.Anthropic()
    risposta = client.beta.messages.create(
        model=modello,
        max_tokens=1024,
        betas=["server-side-fallback-2026-07-01"],
        fallbacks="default",
        output_config={"effort": "low", "format": {"type": "json_schema", "schema": schema}},
        system=("Sei l'assistente di un Gestore della crisi da sovraindebitamento. Classifichi pagine di "
                "documenti ricevuti dai debitori. Rispondi solo con il tipo più adatto tra quelli elencati, "
                "oppure NESSUNO se nessuno è adatto (ad es. pagina di sole firme o istruzioni)."),
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                             "data": base64.standard_b64encode(buf.tobytes()).decode()}},
                {"type": "text", "text": f"Tipi possibili:\n{elenco}\n\nTesto letto dall'OCR (può contenere errori):\n"
                                         f"{testo_ocr[:4000]}"},
            ],
        }],
    )
    if risposta.stop_reason == "refusal":
        return None, "richiesta rifiutata dal modello"
    testo = next((b.text for b in risposta.content if b.type == "text"), "")
    dati = json.loads(testo)
    return (None if dati["sigla"] == "NESSUNO" else dati["sigla"]), dati["motivazione"]
